package com.user.service;

import com.user.model.Contact;
import java.util.List;

public interface ContactService {
    Contact saveContact(Contact contact);
    Contact getContactById(Long id);
    List<Contact> getAllContacts();
    Contact updateContact(Long id, Contact contact);
    void deleteContact(Long id);
}
