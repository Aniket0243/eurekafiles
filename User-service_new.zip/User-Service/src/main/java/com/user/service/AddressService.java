package com.user.service;

import com.user.model.Address;
import java.util.List;

public interface AddressService {
    Address saveAddress(Address address);
    Address getAddressById(Long id);
    List<Address> getAllAddresses();
    Address updateAddress(Long id, Address address);
    void deleteAddress(Long id);
}
